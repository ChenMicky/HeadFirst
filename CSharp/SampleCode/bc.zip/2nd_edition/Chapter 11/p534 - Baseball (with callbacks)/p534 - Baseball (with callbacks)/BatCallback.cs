﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Baseball
{
    delegate void BatCallback(BallEventArgs e);
}
