﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p710___Starbuzz
{
    class StarbuzzData
    {
        public string Name { get; set; }
        public Drink FavoriteDrink { get; set; }
        public int MoneySpent { get; set; }
        public int Visits { get; set; }
    }
}
