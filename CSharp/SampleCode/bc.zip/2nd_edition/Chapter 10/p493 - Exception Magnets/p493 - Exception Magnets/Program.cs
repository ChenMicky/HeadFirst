﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p493___Exception_Magnets
{
    class Program
    {
        public static void Main()
        {
            Console.Write("when it ");
            ExTestDrive.Zero("yes");
            Console.Write(" it ");
            ExTestDrive.Zero("no");
            Console.WriteLine(".");
        }
    }
}