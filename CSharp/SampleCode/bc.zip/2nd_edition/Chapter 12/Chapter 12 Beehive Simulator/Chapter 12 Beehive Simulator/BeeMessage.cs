﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BeehiveSimulator
{
    public delegate void BeeMessage(int ID, string Message);
}
