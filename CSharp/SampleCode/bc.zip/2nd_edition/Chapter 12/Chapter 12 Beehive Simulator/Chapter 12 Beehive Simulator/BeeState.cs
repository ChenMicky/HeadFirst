﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BeehiveSimulator
{
    enum BeeState
    {
        Idle,
        FlyingToFlower,
        GatheringNectar,
        ReturningToHive,
        MakingHoney,
        Retired
    }
}
