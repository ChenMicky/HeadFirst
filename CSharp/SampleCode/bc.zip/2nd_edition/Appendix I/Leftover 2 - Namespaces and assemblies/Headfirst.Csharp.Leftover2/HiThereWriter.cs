﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Headfirst.Csharp.Leftover2
{
    public static class HiThereWriter
    {
        public static void HiThere(string name)
        {
            MessageBox.Show("Hi there! My name is " + name);
        }
    }
}
