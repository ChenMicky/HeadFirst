﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Leftover_6___yield_return
{
    enum Sport
    {
        Football, Baseball,
        Basketball, Hockey,
        Boxing, Rugby, Fencing,
    }
}
