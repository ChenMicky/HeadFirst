﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace p240___Mixed_Messages
{
    class B : A
    {
        public override string m1()
        {
            return "B’s m1, ";
        }
    }
}