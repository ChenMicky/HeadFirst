﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pool_Puzzle
{
    class Rowboat : Boat
    {
        public string rowTheBoat()
        {
            return "stroke natasha";
        }
    }
}