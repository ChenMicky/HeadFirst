Code for Head First JavaScript Programming, by Elisabeth Robson and Eric Freeman.
To be published in March, 2014.

http://wickedlysmart.com/hfjs


